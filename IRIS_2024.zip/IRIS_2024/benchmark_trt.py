import time
import numpy as np
import tensorrt as trt
import pycuda.driver as cuda
import pycuda.autoinit

def load_plugins():
    # Ensure that TensorRT plugins are loaded
    trt.init_libnvinfer_plugins(None, "")

def load_engine(engine_path):
    TRT_LOGGER = trt.Logger(trt.Logger.INFO)
    with open(engine_path, 'rb') as f, trt.Runtime(TRT_LOGGER) as runtime:
        return runtime.deserialize_cuda_engine(f.read())

def allocate_buffers(engine):
    inputs = []
    outputs = []
    bindings = []
    stream = cuda.Stream()
    
    for binding in engine:
        size = trt.volume(engine.get_binding_shape(binding)) * engine.max_batch_size
        dtype = trt.nptype(engine.get_binding_dtype(binding))
        host_mem = cuda.pagelocked_empty(size, dtype)
        device_mem = cuda.mem_alloc(host_mem.nbytes)
        bindings.append(int(device_mem))
        
        if engine.binding_is_input(binding):
            inputs.append({"host": host_mem, "device": device_mem})
        else:
            outputs.append({"host": host_mem, "device": device_mem})
    
    return inputs, outputs, bindings, stream

def do_inference(context, bindings, inputs, outputs, stream, batch_size=1):
    [cuda.memcpy_htod_async(inp["device"], inp["host"], stream) for inp in inputs]
    context.execute_async(batch_size=batch_size, bindings=bindings, stream_handle=stream.handle)
    [cuda.memcpy_dtoh_async(out["host"], out["device"], stream) for out in outputs]
    stream.synchronize()
    return [out["host"] for out in outputs]

def benchmark(engine_path, num_iterations=100):
    load_plugins()
    engine = load_engine(engine_path)
    context = engine.create_execution_context()
    inputs, outputs, bindings, stream = allocate_buffers(engine)

    # Prepare random input data
    input_shape = engine.get_binding_shape(0)
    input_dtype = trt.nptype(engine.get_binding_dtype(0))
    inputs[0]["host"] = np.random.random(input_shape).astype(input_dtype)

    # Warm-up run
    do_inference(context, bindings, inputs, outputs, stream)

    # Benchmarking
    start_time = time.time()
    for _ in range(num_iterations):
        do_inference(context, bindings, inputs, outputs, stream)
    end_time = time.time()

    avg_inference_time = (end_time - start_time) / num_iterations
    print(f"Average inference time over {num_iterations} iterations: {avg_inference_time:.6f} seconds")

if __name__ == '__main__':
    engine_path = "yolov8n-seg.trt"
    benchmark(engine_path)
