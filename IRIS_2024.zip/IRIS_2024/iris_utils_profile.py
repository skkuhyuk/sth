import time
import numpy as np
import cv2
from scipy.ndimage import zoom
import tensorrt as trt
import pycuda.driver as cuda
import pycuda.autoinit


def load_engine(engine_path):
    TRT_LOGGER = trt.Logger(trt.Logger.INFO)
    with open(engine_path, 'rb') as f, trt.Runtime(TRT_LOGGER) as runtime:
        return runtime.deserialize_cuda_engine(f.read())

    
def allocate_buffers(engine):
    inputs = []
    outputs = []
    bindings = []
    stream = cuda.Stream()
    
    for binding in engine:
        size = trt.volume(engine.get_binding_shape(binding)) * engine.max_batch_size
        dtype = trt.nptype(engine.get_binding_dtype(binding))
        host_mem = cuda.pagelocked_empty(size, dtype)
        device_mem = cuda.mem_alloc(host_mem.nbytes)
        bindings.append(int(device_mem))
        
        if engine.binding_is_input(binding):
            inputs.append({"host": host_mem, "device": device_mem})
        else:
            outputs.append({"host": host_mem, "device": device_mem})
    return inputs, outputs, bindings, stream

@profile
def do_inference(context, bindings, inputs, outputs, stream, batch_size=1):
    [cuda.memcpy_htod_async(inp["device"], inp["host"], stream) for inp in inputs]
    context.execute_async(batch_size=batch_size, bindings=bindings, stream_handle=stream.handle)
    [cuda.memcpy_dtoh_async(out["host"], out["device"], stream) for out in outputs]
    stream.synchronize()
    return [out["host"] for out in outputs]

@profile
def run_engine(engine, input_data):
    context = engine.create_execution_context()
    inputs, outputs, bindings, stream = allocate_buffers(engine)

    # Assuming there is only one input
    input_shape = engine.get_binding_shape(0)
    input_dtype = trt.nptype(engine.get_binding_dtype(0))
    inputs[0]["host"] = input_data.astype(input_dtype).ravel()

    # Run inference
    output_data = do_inference(context, bindings, inputs, outputs, stream)

    # Assuming there are two outputs
    output_shape_0 = engine.get_binding_shape(1)
    output_shape_1 = engine.get_binding_shape(2)
    output_0 = output_data[0].reshape(output_shape_0)
    output_1 = output_data[1].reshape(output_shape_1)
    return output_1, output_0 # boxes, masks

@profile
def xywh2xyxy(x):
    # Convert [x, y, w, h] to [x1, y1, x2, y2]
    y = np.zeros_like(x)
    dw = x[..., 2] / 2  # half-width
    dh = x[..., 3] / 2  # half-height
    y[..., 0] = x[..., 0] - dw  # top left x
    y[..., 1] = x[..., 1] - dh  # top left y
    y[..., 2] = x[..., 0] + dw  # bottom right x
    y[..., 3] = x[..., 1] + dh  # bottom right y
    return y

@profile
def nms(boxes, scores, iou_threshold):
    # Perform Non-Maximum Suppression
    indices = np.argsort(scores)[::-1]
    keep = []
    while indices.size > 0:
        i = indices[0]
        keep.append(i)
        if indices.size == 1:
            break
        iou = compute_iou(boxes[i], boxes[indices[1:]])
        indices = indices[1:][iou <= iou_threshold]
    return keep

@profile
def compute_iou(box, boxes):
    # Compute IoU between a box and multiple boxes
    x1 = np.maximum(box[0], boxes[:, 0])
    y1 = np.maximum(box[1], boxes[:, 1])
    x2 = np.minimum(box[2], boxes[:, 2])
    y2 = np.minimum(box[3], boxes[:, 3])
    
    inter_area = np.maximum(0, x2 - x1) * np.maximum(0, y2 - y1)
    box_area = (box[2] - box[0]) * (box[3] - box[1])
    boxes_area = (boxes[:, 2] - boxes[:, 0]) * (boxes[:, 3] - boxes[:, 1])
    
    union_area = box_area + boxes_area - inter_area
    return inter_area / union_area

@profile
def non_max_suppression(
    prediction,
    conf_thres=0.25,
    iou_thres=0.45,
    classes=None,
    agnostic=False,
    multi_label=False,
    labels=(),
    max_det=300,
    nc=0,  # number of classes (optional)
    max_time_img=0.05,
    max_nms=30000,
    max_wh=7680,
    in_place=True,
    rotated=False,
):
    # Checks
    assert 0 <= conf_thres <= 1
    assert 0 <= iou_thres <= 1
    if isinstance(prediction, (list, tuple)):
        prediction = prediction[0]

    bs = prediction.shape[0]  # batch size
    nc = nc or (prediction.shape[1] - 4)  # number of classes
    nm = prediction.shape[1] - nc - 4
    mi = 4 + nc  # mask start index
    xc = prediction[:, 4:mi].max(axis=1) > conf_thres  # candidates

    # Settings
    time_limit = 2.0 + max_time_img * bs  # seconds to quit after
    multi_label &= nc > 1  # multiple labels per box (adds 0.5ms/img)

    prediction = prediction.transpose((0, 2, 1))  # shape(1, 84, 6300) to shape(1, 6300, 84)
    if not rotated:
        if in_place:
            prediction[..., :4] = xywh2xyxy(prediction[..., :4])  # xywh to xyxy
        else:
            prediction = np.concatenate((xywh2xyxy(prediction[..., :4]), prediction[..., 4:]), axis=-1)  # xywh to xyxy

    t = time.time()
    output = [np.zeros((0, 6 + nm))] * bs
    for xi, x in enumerate(prediction):  # image index, image inference
        x = x[xc[xi]]  # confidence

        # Cat apriori labels if autolabelling
        if labels and len(labels[xi]) and not rotated:
            lb = np.array(labels[xi])
            v = np.zeros((len(lb), nc + nm + 4))
            v[:, :4] = xywh2xyxy(lb[:, 1:5])  # box
            v[np.arange(len(lb)), lb[:, 0].astype(int) + 4] = 1.0  # cls
            x = np.concatenate((x, v), axis=0)

        # If none remain process next image
        if not x.shape[0]:
            continue

        # Detections matrix nx6 (xyxy, conf, cls)
        box, cls, mask = np.split(x, [4, 4 + nc], axis=1)

        if multi_label:
            i, j = np.where(cls > conf_thres)
            x = np.concatenate((box[i], x[i, 4 + j[:, None]], j[:, None].astype(float), mask[i]), axis=1)
        else:  # best class only
            conf = cls.max(axis=1)
            j = cls.argmax(axis=1)
            x = np.concatenate((box, conf[:, None], j[:, None].astype(float), mask), axis=1)[conf > conf_thres]

        # Filter by class
        if classes is not None:
            x = x[np.isin(x[:, 5], classes)]

        # Check shape
        n = x.shape[0]  # number of boxes
        if not n:  # no boxes
            continue
        if n > max_nms:  # excess boxes
            x = x[x[:, 4].argsort()[::-1][:max_nms]]  # sort by confidence and remove excess boxes

        # Batched NMS
        c = x[:, 5:6] * (0 if agnostic else max_wh)  # classes
        scores = x[:, 4]  # scores
        boxes = x[:, :4] + c  # boxes (offset by class)
        i = nms(boxes, scores, iou_thres)  # NMS
        i = i[:max_det]  # limit detections

        output[xi] = x[i]
        if (time.time() - t) > time_limit:
            print(f"WARNING ⚠️ NMS time limit {time_limit:.3f}s exceeded")
            break  # time limit
    return output

@profile
def crop_mask(masks, boxes):
    n, h, w = masks.shape
    x1, y1, x2, y2 = np.split(boxes[:, :, None], 4, axis=1)  # x1 shape(n,1,1)
    r = np.arange(w)[None, None, :]  # rows shape(1,1,w)
    c = np.arange(h)[None, :, None]  # cols shape(1,h,1)
    return masks * ((r >= x1) * (r < x2) * (c >= y1) * (c < y2))
            
@profile
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

@profile
def bilinear_interpolate(masks, shape):
    c, h, w = masks.shape
    target_h, target_w = shape

    zoom_factors = (1, target_h / h, target_w / w)
    interpolated_masks = zoom(masks, zoom_factors, order=1)  # order=1 for bilinear interpolation
    return interpolated_masks

@profile
def process_mask(protos, masks_in, bboxes, shape, upsample=False):
    c, mh, mw = protos.shape
    ih, iw = shape

    # Apply the masks
    masks = sigmoid(np.dot(masks_in, protos.reshape(c, -1)))
    masks = masks.reshape(-1, mh, mw)

    # Calculate ratios for resizing the bounding boxes
    width_ratio = mw / iw
    height_ratio = mh / ih

    # Downsample the bounding boxes
    downsampled_bboxes = bboxes.copy()
    downsampled_bboxes[:, 0] *= width_ratio
    downsampled_bboxes[:, 2] *= width_ratio
    downsampled_bboxes[:, 3] *= height_ratio
    downsampled_bboxes[:, 1] *= height_ratio

    # Crop the masks according to the downsampled bounding boxes
    masks = crop_mask(masks, downsampled_bboxes)

    if upsample:
        masks = bilinear_interpolate(masks, shape)
    return masks > 0.5

@profile
def masks2segments(masks, strategy="largest"):
    segments = []
    for x in masks.astype("uint8"):
        contours, _ = cv2.findContours(x, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            if strategy == "concat":  # concatenate all segments
                c = np.concatenate([contour.reshape(-1, 2) for contour in contours])
            elif strategy == "largest":  # select largest segment
                c = np.array(contours[np.array([len(contour) for contour in contours]).argmax()]).reshape(-1, 2)
        else:
            c = np.zeros((0, 2))  # no segments found
        segments.append(c.astype("float32"))
    return segments

@profile
def clip_boxes(boxes, shape):
    boxes[..., [0, 2]] = boxes[..., [0, 2]].clip(0, shape[1])  # x1, x2
    boxes[..., [1, 3]] = boxes[..., [1, 3]].clip(0, shape[0])  # y1, y2
    return boxes

@profile
def clip_coords(coords, shape):
    coords[..., 0] = coords[..., 0].clip(0, shape[1])  # x
    coords[..., 1] = coords[..., 1].clip(0, shape[0])  # y
    return coords

@profile
def scale_boxes(img1_shape, boxes, img0_shape, ratio_pad=None, padding=True, xywh=False):
    if ratio_pad is None:  # calculate from img0_shape
        gain = min(img1_shape[0] / img0_shape[0], img1_shape[1] / img0_shape[1])  # gain  = old / new
        pad = (
            round((img1_shape[1] - img0_shape[1] * gain) / 2 - 0.1),
            round((img1_shape[0] - img0_shape[0] * gain) / 2 - 0.1),
        )  # wh padding
    else:
        gain = ratio_pad[0][0]
        pad = ratio_pad[1]

    if padding:
        boxes[..., 0] -= pad[0]  # x padding
        boxes[..., 1] -= pad[1]  # y padding
        if not xywh:
            boxes[..., 2] -= pad[0]  # x padding
            boxes[..., 3] -= pad[1]  # y padding
    boxes[..., :4] /= gain
    return clip_boxes(boxes, img0_shape)

@profile
def scale_coords(img1_shape, coords, img0_shape, ratio_pad=None, normalize=False, padding=True):
    if ratio_pad is None:  # calculate from img0_shape
        gain = min(img1_shape[0] / img0_shape[0], img1_shape[1] / img0_shape[1])  # gain  = old / new
        pad = ((img1_shape[1] - img0_shape[1] * gain) / 2, (img1_shape[0] - img0_shape[0] * gain) / 2)  # wh padding
    else:
        gain = ratio_pad[0][0]
        pad = ratio_pad[1]

    if padding:
        coords[..., 0] -= pad[0]  # x padding
        coords[..., 1] -= pad[1]  # y padding
    coords[..., 0] /= gain
    coords[..., 1] /= gain
    coords = clip_coords(coords, img0_shape)
    if normalize:
        coords[..., 0] /= img0_shape[1]  # width
        coords[..., 1] /= img0_shape[0]  # height
    return coords

@profile
def resize_and_padding(img, new_shape, auto=False, scaleFill=False, scaleup=True, center=True, stride=32):
    shape = img.shape[:2] #(h, w)
    
    # Scale ratio (new / old)
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    if not scaleup:  # only scale down, do not scale up (for better val mAP)
        r = min(r, 1.0)

    # Compute padding
    ratio = r, r  # width, height ratios
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]  # wh padding
    if auto:  # minimum rectangle
        dw, dh = np.mod(dw, self.stride), np.mod(dh, self.stride)  # wh padding
    elif scaleFill:  # stretch
        dw, dh = 0.0, 0.0
        new_unpad = (new_shape[1], new_shape[0])
        ratio = new_shape[1] / shape[1], new_shape[0] / shape[0]  # width, height ratios

    if center:
        dw /= 2  # divide padding into 2 sides
        dh /= 2

    if shape[::-1] != new_unpad:  # resize
        img = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)) if center else 0, int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)) if center else 0, int(round(dw + 0.1))
    img = cv2.copyMakeBorder(
        img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114, 114, 114)
    )  # add border
    return img

@profile
def preprocess(rgb_img, target_shape, is_rgb=True):
    rgb_img = resize_and_padding(rgb_img, target_shape)
    rgb_img = rgb_img[None, ...]
    if not is_rgb:
        rgb_img = rgb_img[..., ::-1]
    rgb_img = rgb_img.transpose((0, 3, 1, 2))
    rgb_img = rgb_img.astype(np.float32) / 255
    return rgb_img
    
@profile
def postprocess(model_outputs, target_shape, orig_img_shape, conf_thres=0.25, iou_thres=0.7, max_det=300, nc=10):
    pred, proto = non_max_suppression(model_outputs[0], conf_thres=conf_thres, iou_thres=iou_thres, max_det=max_det, nc=nc)[0], model_outputs[1][0]
    masks = process_mask(proto, pred[:, 6:], pred[:, :4], target_shape, upsample=True)
    pred[:, :4] = scale_boxes(target_shape, pred[:, :4], orig_img_shape)
    boxes = pred[:, :4]
    clss  = pred[:, 5]
    segs = [
        scale_coords(target_shape, x, orig_img_shape, normalize=False).flatten().tolist()
        for x in masks2segments(masks)
    ]
    
    return clss, boxes, segs
    
@profile
def artifacts2output(clss, boxes, segs):
    out_list = []
    for cls, box, seg in zip(clss, boxes, segs):
        cls = int(cls)
        if cls < 7:
            out_list.append({
                "type": cls + 1,
                "x": box[0],
                "y": box[1],
                "width": box[2] - box[0],
                "height": box[3] - box[1],
                "segmentation": [],
            })
        else:
            out_list.append({
                "type": cls + 1,
                "x": -1,
                "y": -1,
                "width": -1,
                "height": -1,
                "segmentation": seg,
            })
    return out_list


if __name__ == '__main__':
    engine_path = "IRIS.trt"
    engine = load_engine(engine_path)
    input_shape = engine.get_binding_shape(0) # (1, 3, h, w)
    
    img_path = "../images/00001.jpg"
    img_arr = cv2.imread(str(img_path))
    orig_img_shape = img_arr.shape
    
    img_arr = preprocess(img_arr, input_shape[2:], is_rgb=False)
    preds = run_engine(engine, img_arr)
    
    clss, boxes, segs = postprocess(preds, input_shape[2:], orig_img_shape)
    out_list = artifacts2output(clss, boxes, segs)