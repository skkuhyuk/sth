import sys
import json
import tensorrt as trt
from tensorrt import LayerInformationFormat


def _get_engine(engine_path):
    logger = trt.Logger(trt.Logger.WARNING)
    logger.min_severity = trt.Logger.Severity.ERROR
    runtime = trt.Runtime(logger)
    trt.init_libnvinfer_plugins(logger,'') # initialize TensorRT plugins
    with open(engine_path, "rb") as f:
        serialized_engine = f.read()
    engine = runtime.deserialize_cuda_engine(serialized_engine)
    return engine

if __name__ == '__main__':
    engine_path = sys.argv[1]
    engine = _get_engine(engine_path)
    inspector = engine.create_engine_inspector()
    engine_dict = eval(inspector.get_engine_information(LayerInformationFormat.JSON))
    
    with open(engine_path.replace('.trt', '.json'), 'w') as f:
        json.dump(engine_dict, f, indent=4)
