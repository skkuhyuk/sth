import sys
from pathlib import Path
import tensorrt as trt
import numpy as np

def add_nms_plugin(network, boxes_tensor, scores_tensor, num_classes, score_threshold=0.5, iou_threshold=0.5, max_output_boxes=100):
    plugin_creator = trt.get_plugin_registry().get_plugin_creator("BatchedNMS_TRT", "1", "")
    if not plugin_creator:
        raise RuntimeError("BatchedNMS_TRT plugin not found")
    
    # Create PluginFields
    share_location_field = trt.PluginField("shareLocation", np.array([1], dtype=np.int32), trt.PluginFieldType.INT32)
    background_label_id_field = trt.PluginField("backgroundLabelId", np.array([-1], dtype=np.int32), trt.PluginFieldType.INT32)  # Typically -1 for no background class
    num_classes_field = trt.PluginField("numClasses", np.array([num_classes], dtype=np.int32), trt.PluginFieldType.INT32)
    top_k_field = trt.PluginField("topK", np.array([max_output_boxes], dtype=np.int32), trt.PluginFieldType.INT32)
    keep_top_k_field = trt.PluginField("keepTopK", np.array([max_output_boxes], dtype=np.int32), trt.PluginFieldType.INT32)
    score_threshold_field = trt.PluginField("scoreThreshold", np.array([score_threshold], dtype=np.float32), trt.PluginFieldType.FLOAT32)
    iou_threshold_field = trt.PluginField("iouThreshold", np.array([iou_threshold], dtype=np.float32), trt.PluginFieldType.FLOAT32)
    
    # Collect the PluginFields
    field_collection = [
        share_location_field,
        background_label_id_field,
        num_classes_field,
        top_k_field,
        keep_top_k_field,
        score_threshold_field,
        iou_threshold_field
    ]
    
    plugin_fields = trt.PluginFieldCollection(field_collection)
    nms_layer = plugin_creator.create_plugin("BatchedNMS", plugin_fields)
    return network.add_plugin_v2([boxes_tensor, scores_tensor], nms_layer)

def build_engine_with_nms(onnx_file_path):
    TRT_LOGGER = trt.Logger(trt.Logger.INFO)
    builder = trt.Builder(TRT_LOGGER)
    network = builder.create_network(1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))
    parser = trt.OnnxParser(network, TRT_LOGGER)

    with open(onnx_file_path, 'rb') as model:
        if not parser.parse(model.read()):
            for error in range(parser.num_errors):
                print(parser.get_error(error))
            raise ValueError("Failed to parse ONNX model")

    # Assuming the output of the model is [detection, masks]
    detection_tensor = network.get_output(0)  # Shape: [1, 46, 8400]
    masks_tensor = network.get_output(1)  # Shape: [1, 32, 160, 160]

    # Remove the original outputs from the network
    network.unmark_output(detection_tensor)
    network.unmark_output(masks_tensor)

    # Split detection tensor into boxes and scores
    # Shape: [1, 46, 8400] -> [1, 10, 8400] for scores and [1, 4, 8400] for boxes
    scores_tensor = network.add_slice(detection_tensor, start=(0, 0, 0), shape=(1, 10, 8400), stride=(1, 1, 1)).get_output(0)
    boxes_tensor = network.add_slice(detection_tensor, start=(0, 10, 0), shape=(1, 4, 8400), stride=(1, 1, 1)).get_output(0)

    # Convert xywh to xyxy format
    x_center = network.add_slice(boxes_tensor, start=(0, 0, 0), shape=(1, 1, 8400), stride=(1, 1, 1)).get_output(0)
    y_center = network.add_slice(boxes_tensor, start=(0, 1, 0), shape=(1, 1, 8400), stride=(1, 1, 1)).get_output(0)
    width = network.add_slice(boxes_tensor, start=(0, 2, 0), shape=(1, 1, 8400), stride=(1, 1, 1)).get_output(0)
    height = network.add_slice(boxes_tensor, start=(0, 3, 0), shape=(1, 1, 8400), stride=(1, 1, 1)).get_output(0)

    # Create constant tensors with shape (1, 1, 8400) for the element-wise operations
    half_constant = np.full((1, 1, 8400), 0.5, dtype=np.float32)
    
    half_width = network.add_elementwise(width, network.add_constant((1, 1, 8400), trt.Weights(half_constant)).get_output(0), trt.ElementWiseOperation.PROD).get_output(0)
    half_height = network.add_elementwise(height, network.add_constant((1, 1, 8400), trt.Weights(half_constant)).get_output(0), trt.ElementWiseOperation.PROD).get_output(0)

    x_min = network.add_elementwise(x_center, half_width, trt.ElementWiseOperation.SUB).get_output(0)
    y_min = network.add_elementwise(y_center, half_height, trt.ElementWiseOperation.SUB).get_output(0)
    x_max = network.add_elementwise(x_center, half_width, trt.ElementWiseOperation.SUM).get_output(0)
    y_max = network.add_elementwise(y_center, half_height, trt.ElementWiseOperation.SUM).get_output(0)

    xyxy_boxes = network.add_concatenation([x_min, y_min, x_max, y_max]).get_output(0)
    xyxy_boxes = network.add_shuffle(xyxy_boxes)
    xyxy_boxes.reshape_dims = (1, 8400, 1, 4)

    # Reshape scores to [1, 8400, 10] (batch_size, number_boxes, number_classes)
    scores_tensor = network.add_shuffle(scores_tensor)
    scores_tensor.reshape_dims = (1, 8400, 10)

    # Add NMS plugin layer
    nms_layer = add_nms_plugin(network, xyxy_boxes.get_output(0), scores_tensor.get_output(0), num_classes=10)

    # Mark new outputs
    network.mark_output(nms_layer.get_output(0))  # num_detections
    network.mark_output(nms_layer.get_output(1))  # nmsed_boxes
    network.mark_output(nms_layer.get_output(2))  # nmsed_scores
    network.mark_output(nms_layer.get_output(3))  # nmsed_classes
    network.mark_output(masks_tensor)  # Mask output remains unchanged

    # Build the engine
    config = builder.create_builder_config()
    config.max_workspace_size = 1 << 30  # Adjust workspace size if necessary
    engine = builder.build_engine(network, config)

    # Save the engine to file
    engine_path = onnx_file_path.with_suffix(".trt")
    with open(engine_path, "wb") as f:
        f.write(engine.serialize())
        

if __name__ == '__main__':
    assert len(sys.argv) == 2
    onnx_file_path = Path(sys.argv[1])
    build_engine_with_nms(onnx_file_path)
